package ola_mundo;

public class Ola {

	public static void main(String[] args) {
		System.out.println("Olá, mundo do github!");

	}

}
